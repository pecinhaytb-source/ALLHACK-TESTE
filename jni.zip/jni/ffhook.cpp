#include <jni.h>
#include <dlfcn.h>
#include <sys/mman.h>
#include <android/log.h>
#include <unistd.h>
#include <pthread.h>
#include <fstream>
#include <cmath>

#define LOG_TAG "FFHook"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

// Offsets Base (Ajuste com o Il2CppDumper da versão atual)
#define OFF_GET_CUR_HP       0x27a05f0ULL
#define OFF_GET_MAX_HP       0x27a072cULL
#define OFF_SET_AIM_ROTATION 0x274648cULL
#define OFF_VIEW_MATRIX      0xBC
#define OFF_ENTITY_LIST      0x68
#define BONE_HEAD            0x3AC

bool espLine = false, espBox = false, espHealth = false;
bool aimCollider = false, aimSilent = false;

struct Matrix4x4 { float m[16]; };
struct Vector3 { float x, y, z; };

// Lê as flags escritas pelo APK
bool get_flag(const char* path) {
    std::ifstream f(path);
    int v = 0;
    if (f >> v) return v == 1;
    return false;
}

// Função de leitura de memória
template<typename T>
T read_mem(uintptr_t addr) { return *(T*)addr; }

// Conversão de mundo 3D para tela 2D
bool world_to_screen(const Matrix4x4& matrix, const Vector3& world, float sw, float sh, Vector3& out) {
    float w = matrix.m[3] * world.x + matrix.m[7] * world.y + matrix.m[11] * world.z + matrix.m[15];
    if (w < 0.001f) return false;
    float x = matrix.m[0] * world.x + matrix.m[4] * world.y + matrix.m[8] * world.z + matrix.m[12];
    float y = matrix.m[1] * world.x + matrix.m[5] * world.y + matrix.m[9] * world.z + matrix.m[13];
    out.x = (sw / 2.0f) + (x / w) * (sw / 2.0f);
    out.y = (sh / 2.0f) - (y / w) * (sh / 2.0f);
    return true;
}

static void patch_ret_imm32(uintptr_t addr, int32_t imm) {
    uint32_t mov_w0 = 0x52800000 | ((imm & 0xFFFF) << 5);
    uint32_t ret = 0xD65F03C0;
    uintptr_t page = addr & ~0xFFFULL;
    mprotect((void*)page, 0x2000, PROT_READ | PROT_WRITE | PROT_EXEC);
    *(uint32_t*)addr = mov_w0;
    *(uint32_t*)(addr + 4) = ret;
    __builtin___clear_cache((char*)addr, (char*)(addr + 8));
    mprotect((void*)page, 0x2000, PROT_READ | PROT_EXEC);
}

void* cheat_thread(void*) {
    void* il2cpp = nullptr;
    while (!(il2cpp = dlopen("libil2cpp.so", RTLD_NOLOAD | RTLD_LAZY))) sleep(1);
    
    // uintptr_t base = (uintptr_t)il2cpp; // Base do jogo

    while (true) {
        // Atualiza as flags em tempo real
        espLine = get_flag("/data/local/tmp/ff_esp_line");
        espBox = get_flag("/data/local/tmp/ff_esp_box");
        espHealth = get_flag("/data/local/tmp/ff_esp_health");
        aimCollider = get_flag("/data/local/tmp/ff_aim_collider");
        aimSilent = get_flag("/data/local/tmp/ff_aim_silent");

        if (espBox || aimCollider) {
            // Lógica de render/aimbot rodaria aqui a 60fps
            // Exemplo: Pegar ViewMatrix, iterar inimigos...
        }

        usleep(16000); // 60 FPS
    }
    return nullptr;
}

__attribute__((constructor))
void init_ffhook() {
    pthread_setname_np(pthread_self(), "RenderThread");
    
    // Inicia a thread do ESP/Aimbot
    pthread_t t;
    pthread_create(&t, nullptr, cheat_thread, nullptr);
    
    // Aplica patches fixos após delay
    sleep(2);
    void* il2cpp = dlopen("libil2cpp.so", RTLD_NOLOAD | RTLD_LAZY);
    if (il2cpp) {
        uintptr_t base = (uintptr_t)il2cpp;
        patch_ret_imm32(base + OFF_GET_CUR_HP, 9999);
        patch_ret_imm32(base + OFF_GET_MAX_HP, 9999);
    }
}