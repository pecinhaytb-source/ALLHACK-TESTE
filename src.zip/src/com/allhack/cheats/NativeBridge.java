package com.allhack.cheats;

public class NativeBridge {
    public static void setEspLine(boolean e) { run("ff_esp_line", e); }
    public static void setEspPlayer(boolean e) { run("ff_esp_player", e); }
    public static void setEspHealth(boolean e) { run("ff_esp_health", e); }
    public static void setEspSkeleton(boolean e) { run("ff_esp_skeleton", e); }
    public static void setEspBox(boolean e) { run("ff_esp_box", e); }
    public static void setAimCollider(boolean e) { run("ff_aim_collider", e); }
    public static void setAimSilent(boolean e) { run("ff_aim_silent", e); }
    public static void setFov(int f) { }

    private static void run(final String key, final boolean val) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String path = "/data/local/tmp/" + key;
                    Process p = Runtime.getRuntime().exec("su");
                    java.io.DataOutputStream os = new java.io.DataOutputStream(p.getOutputStream());
                    os.writeBytes("echo " + (val ? "1" : "0") + " > " + path + "\n");
                    os.writeBytes("exit\n");
                    os.flush();
                    os.close();
                } catch (Exception e) {}
            }
        }).start();
    }
}