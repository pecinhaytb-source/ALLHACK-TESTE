package com.allhack.cheats;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.TextView;

public class FloatingService extends Service {
    private WindowManager wm;
    private View view;

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        
        // Foreground Service para não ser morto
        String channelId = "allhack_channel";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId, "ALLHACK", NotificationManager.IMPORTANCE_LOW);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
            Notification notification = new Notification.Builder(this, channelId)
                    .setContentTitle("ALLHACK ATIVO")
                    .setContentText("Painel rodando.")
                    .setSmallIcon(android.R.drawable.ic_menu_info_details)
                    .build();
            startForeground(1, notification);
        }

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(Color.parseColor("#121212"));
        layout.setPadding(30, 30, 30, 30);

        TextView tv = new TextView(this);
        tv.setText("ALLHACK");
        tv.setTextColor(Color.RED);
        layout.addView(tv);

        // Funções VISUAIS
        CheckBox cbLine = new CheckBox(this);
        cbLine.setText("ESP Linha");
        cbLine.setTextColor(Color.WHITE);
        cbLine.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean c) { NativeBridge.setEspLine(c); }
        });
        layout.addView(cbLine);

        CheckBox cbBox = new CheckBox(this);
        cbBox.setText("ESP Box");
        cbBox.setTextColor(Color.WHITE);
        cbBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean c) { NativeBridge.setEspBox(c); }
        });
        layout.addView(cbBox);

        CheckBox cbHp = new CheckBox(this);
        cbHp.setText("ESP Vida");
        cbHp.setTextColor(Color.WHITE);
        cbHp.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean c) { NativeBridge.setEspHealth(c); }
        });
        layout.addView(cbHp);

        // Funções AIMBOT
        CheckBox cbAimCollider = new CheckBox(this);
        cbAimCollider.setText("Aimbot Colíder");
        cbAimCollider.setTextColor(Color.WHITE);
        cbAimCollider.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean c) { NativeBridge.setAimCollider(c); }
        });
        layout.addView(cbAimCollider);

        CheckBox cbAimSilent = new CheckBox(this);
        cbAimSilent.setText("Aimsilent");
        cbAimSilent.setTextColor(Color.WHITE);
        cbAimSilent.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean c) { NativeBridge.setAimSilent(c); }
        });
        layout.addView(cbAimSilent);

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O 
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY 
                : WindowManager.LayoutParams.TYPE_PHONE;
                
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, 
            WindowManager.LayoutParams.WRAP_CONTENT, 
            type, 
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, 
            PixelFormat.TRANSLUCENT);
            
        params.gravity = Gravity.TOP | Gravity.START; 
        params.x = 100; 
        params.y = 100;
        
        view = layout;
        wm.addView(view, params);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (view != null) wm.removeView(view);
    }
}